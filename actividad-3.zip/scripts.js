const n = 4

var count = 4
var total = 0
while (count > 0) {
    console.log(`Quedan ${count} intentos`);
    var nota = prompt("Ingrese 4 notas para calcular el promedio del estudiante: ");
    console.log('La nota ingresada es: ', nota);
    count--;
    var numero = parseFloat(nota)


total += numero
console.log('El total es: ', total);
if (count === 0) {
    var promedio = total / n
    console.log(`El promedio es: ${promedio}`);
    document.writeln(`<h1>El promedio del usuario es: ${promedio}</h1>`);
}
}

  

 
